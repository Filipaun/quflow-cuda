class ssht_input_error(TypeError):
    """Raise this when inputs are the wrong type"""


class ssht_spin_error(ValueError):
    """Raise this when the spin is none zero but Reality is true"""
